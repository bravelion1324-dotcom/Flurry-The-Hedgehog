from kivy.app import App
from kivy.uix.widget import Widget
from kivy.graphics import Rectangle, Color, Triangle, Line
from kivy.core.window import Window
from kivy.clock import Clock
from kivy.core.audio import SoundLoader
from kivy.core.image import Image as CoreImage
import os, math, random

T, FPS, G, MF, J = 64, 1 / 30, 0.8, -12, 14

LEVEL_MAPS = [
    ["." * 50, "...................E.....................E........", "W...P..../\\..O..WW...C..WW.../\\..O..WW...B....GW", "W" * 50],
    ["....WWWW..........WWWW............................", "...........E..............E..............E........", "W...P..WW.....WW...C...WW....O...WW...WW...B....GW", "W" * 50],
    ["..................................................", ".........E...................E....................", "W...P...O...WW...C...WW...O...WW...O...WW...B....GW", "W" * 50],
    ["..................................................", "......................E...................E.......", "W...P./\\...../\\...C.../\\...../\\...WW.../\\...B....GW", "W" * 50],
    [".......WWWW..............WWWW.....................", "...............E..................E...............", "W...P..WW.../\\..WW..C..WW.../\\..WW...O..WW..B....GW", "W" * 50],
    ["..................................................", ".....E...................E...................E....", "W...P...O...O...WW..C..WW...O...O...WW..O...B....GW", "W" * 50],
    ["..................................................", "...............E...................E..............", "W...P./\\\\/..WW...C.../\\\\/..WW.../\\\\/..WW...B....GW", "W" * 50],
    ["....WW..WW..WW............WW..WW..WW..............", "...............E.....................E............", "W...P..WW.WW.WW..C..WW.WW.WW..WW.WW.WW..WW..B....GW", "W" * 50],
    ["..WW.........WW.........WW.........WW.............", ".......E...........E...........E...........E......", "W...P./\\..O../\\..WW.C./\\..O../\\..WW..O..WW..B....GW", "W" * 50]
]

LEVELS = [
    ("diamond hill", "Diamond Hill.png", "dhm.mp3", (0.1, 0.6, 0.2, 1)),
    ("minecave", "Minecave.png", "minc.mp3", (0.3, 0.2, 0.1, 1)),
    ("candy land", "Candy Land.png", "cl.mp3", (0.9, 0.4, 0.6, 1)),
    ("big canyon", "Big Canyon.png", "ap.mp3", (0.8, 0.4, 0.1, 1)),
    ("acidic plant", "Acidic Plant.png", "bc.mp3", (0.2, 0.8, 0.2, 1)),
    ("dark sea", "Dark Sea.png", "ds.mp3", (0.0, 0.2, 0.5, 1)),
    ("dark forest", "Dark Forest.png", "df.mp3", (0.05, 0.25, 0.1, 1)),
    ("black rocket", "Black Rocket.png", "br.mp3", (0.1, 0.1, 0.15, 1)),
    ("final dark space", "Dark Space.png", "finale.mp3", (0.02, 0.0, 0.08, 1))
]

class GameWidget(Widget):
    def __init__(self, **kw):
        super().__init__(**kw)
        self.lvl, self.cur_snd = 0, None
        self.in_ending = False
        self.tex = {k: CoreImage(f"{k}.png").texture if os.path.exists(f"{k}.png") else None 
                    for k in ["Flurry", "Dr Roctis", "Crab"] + [l[0] for l in LEVELS]}
        self.sfx = {k: SoundLoader.load(f) for k, f in [("jump", "Jump.wav"), ("hit", "Hit.wav"), ("exp", "Explosion.wav"), ("vic", "Level Finished.mp3")] if os.path.exists(f)}
        self.init_lvl(0)
        Clock.schedule_interval(self.update, FPS)

    def play_sfx(self, k):
        if k in self.sfx and self.sfx[k]:
            self.sfx[k].stop()
            self.sfx[k].play()

    def play_track(self, fn):
        if self.cur_snd:
            try: self.cur_snd.stop()
            except: pass
            self.cur_snd = None
        if fn and os.path.exists(fn):
            self.cur_snd = SoundLoader.load(fn)
            if self.cur_snd:
                self.cur_snd.loop = True
                self.cur_snd.play()

    def coll(self, a, b):
        return a[0] < b[0] + b[2] and a[0] + a[2] > b[0] and a[1] < b[1] + b[3] and a[1] + a[3] > b[1]

    def respawn(self):
        self.play_sfx("exp")
        self.px, self.py = self.cpx, self.cpy

    def init_lvl(self, i):
        self.walls, self.sl_up, self.sl_dn, self.loops, self.check, self.enemies, self.bosses = [], [], [], [], [], [], []
        self.bombs, self.spikes, self.hazards, self.lasers, self.projs, self.goals = [], [], [], [], [], []
        self.px, self.py, self.pw, self.ph, self.vx, self.vy, self.cam_x, self.j_timer = 100, 200, 32, 40, 0, 0, 0, 0
        self.ground = self.in_loop = self.boss_act = self.cleared = False
        self.loop_a = self.loop_cx = self.loop_cy = self.loop_dir = self.loop_cd = 0
        
        m_hp = 3 if i < 2 else (5 if i < 6 else (6 if i < 8 else 9))
        for r_i, r in enumerate(reversed(LEVEL_MAPS[i])):
            for c_i, c in enumerate(r):
                x, y, rect = c_i * T, r_i * T, [c_i * T, r_i * T, T, T]
                if c == 'W': self.walls.append(rect)
                elif c == '/': self.sl_up.append(rect)
                elif c == '\\': self.sl_dn.append(rect)
                elif c == 'O': self.loops.append([x, y, T * 2, T * 2])
                elif c == 'E': self.enemies.append([x, y, T, T, 2])
                elif c == 'C': self.check.append(rect)
                elif c == 'B': self.bosses.append([x, y, T * 2, T * 2, 4, m_hp, y, 0.0, 0, 0, 0.0, True, m_hp, {}])
                elif c == 'G': self.goals.append(rect)
                elif c == 'P': self.px, self.py, self.cpx, self.cpy = x, y, x, y
        self.boss_def = (len(self.bosses) == 0)
        self.play_track(LEVELS[i][2])

    def init_ending(self):
        self.in_ending = True
        self.ending_t = 0.0
        self.rocket_x = Window.width * 0.65
        self.rocket_y = Window.height + 150
        self.play_track("Ending.mp3")

    def on_touch_down(self, t):
        if self.cleared or self.in_ending or t.y >= 200: return
        if t.x < Window.width * 0.2: self.vx = -7
        elif t.x < Window.width * 0.4: self.vx = 7
        elif t.x > Window.width * 0.5 and self.ground and not self.in_loop:
            self.vy, self.ground = J, False
            self.play_sfx("jump")

    def on_touch_up(self, t):
        if t.x < Window.width * 0.4: self.vx = 0

    def update(self, dt):
        if self.in_ending:
            self.ending_t += dt
            if self.rocket_y > 80:
                self.rocket_y -= 90 * dt
                self.rocket_x += math.sin(self.ending_t * 12) * 2.5
            self.canvas.clear()
            self.draw_ending()
            return

        if self.cleared:
            self.vx = self.vy = 0
            self.j_timer += dt
            if self.j_timer > 2.0:
                self.lvl += 1
                if self.lvl < len(LEVEL_MAPS): 
                    self.init_lvl(self.lvl)
                else:
                    self.init_ending()
            return

        self.loop_cd = max(0, self.loop_cd - 1)
        if self.in_loop:
            self.loop_a += 0.25 * self.loop_dir
            self.px = self.loop_cx + T * math.sin(self.loop_a) - self.pw / 2
            self.py = self.loop_cy - T * math.cos(self.loop_a)
            if abs(self.loop_a) >= 2 * math.pi:
                self.in_loop, self.loop_cd, self.py = False, 20, self.loop_cy - T
                self.px += 25 * self.loop_dir
                self.vx, self.vy, self.ground = (7 if self.loop_dir > 0 else -7), 0, True
        else:
            self.vy = max(MF, self.vy - G)
            self.px += self.vx
            p = [self.px, self.py, self.pw, self.ph]
            for w in self.walls:
                if self.coll(p, w):
                    self.px = w[0] - self.pw if self.vx > 0 else w[0] + w[2]
                    p[0] = self.px

            self.py += self.vy
            p[1], self.ground = self.py, False
            for w in self.walls:
                if self.coll(p, w):
                    if self.vy < 0: self.py, self.vy, self.ground = w[1] + w[3], 0, True
                    elif self.vy > 0: self.py, self.vy = w[1] - self.ph, 0
                    p[1] = self.py

            for sl, is_u in [(self.sl_up, True), (self.sl_dn, False)]:
                for s in sl:
                    if s[0] < self.px + self.pw and self.px < s[0] + s[2]:
                        rx = max(0, min(s[2], (self.px + self.pw / 2) - s[0]))
                        sy = s[1] + rx if is_u else s[1] + (s[3] - rx)
                        if self.py <= sy and self.py + self.vy <= sy + 12 and self.py >= s[1] - 10:
                            self.py, self.vy, self.ground = sy, 0, True

            if self.loop_cd <= 0:
                for lp in self.loops:
                    if self.coll(p, lp) and abs(self.vx) >= 4:
                        self.in_loop, self.loop_cx, self.loop_cy = True, lp[0] + lp[2]/2, lp[1] + lp[3]/2
                        self.loop_dir, self.loop_a = (1 if self.vx >= 0 else -1), 0
                        break

        p = [self.px, self.py, self.pw, self.ph]
        for cp in self.check:
            if self.coll(p, cp): self.cpx, self.cpy = cp[0], cp[1]

        for e in list(self.enemies):
            e[0] += e[4]
            if any(self.coll([e[0], e[1], e[2], e[3]], w) for w in self.walls):
                e[4] *= -1; e[0] += e[4]
            if self.coll(p, [e[0], e[1], e[2], e[3]]):
                if self.vy < 0 or self.py > e[1] + e[3] * 0.3:
                    self.enemies.remove(e); self.vy = 10; self.play_sfx("hit")
                else: self.respawn()

        for sp in list(self.spikes):
            sp[1] -= 9
            if sp[1] < 0: self.spikes.remove(sp)
            elif self.coll(p, sp[:4]): self.respawn(); self.spikes.remove(sp)

        for pr in list(self.projs):
            pr[0] += pr[2]; pr[1] += pr[3]; pr[6] -= dt
            if pr[6] <= 0 or any(self.coll(pr[:4], w) for w in self.walls): self.projs.remove(pr)
            elif self.coll(p, pr[:4]): self.respawn(); self.projs.remove(pr)

        for bm in list(self.bombs):
            bm[0] += bm[2]; bm[1] += bm[3]; bm[3] -= G * 0.4
            if any(self.coll(bm[:4], w) for w in self.walls) or bm[1] < -100:
                self.play_sfx("exp"); self.bombs.remove(bm)
            elif self.coll(p, bm[:4]): self.respawn(); self.bombs.remove(bm)

        for b in list(self.bosses):
            if abs(self.px - b[0]) < 450 and not self.boss_act:
                self.boss_act = True
                self.play_track("boss8.mp3" if self.lvl < 8 else "fb.mp3")

            cd = b[13]
            l = self.lvl
            if l == 0:
                b[0] += b[4]
                if any(self.coll(b[:4], w) for w in self.walls): b[4] *= -1
                b[7] += 0.08; b[1] = b[6] + math.sin(b[7]) * 40
                if self.boss_act:
                    b[8] += 1
                    if b[8] >= 75:
                        b[8] = 0
                        self.bombs.append([b[0] + T, b[1] + T, (-5 if self.px < b[0] else 5), 6, 20, 20])
            elif l == 1:
                if self.boss_act:
                    sub_st = cd.get("sub_st", 0)
                    if sub_st == 0:
                        cd["vis"] = True
                        b[0] -= 12
                        if any(self.coll(b[:4], w) for w in self.walls):
                            b[0] += 12
                            cd["sub_st"] = 1
                    elif sub_st == 1:
                        cd["vis"] = True
                        b[0] += 12
                        if any(self.coll(b[:4], w) for w in self.walls):
                            b[0] -= 12
                            cd["sub_st"] = 2
                            cd["t"] = 0
                            cd["vis"] = False
                    elif sub_st == 2:
                        cd["vis"] = False
                        cd["t"] = cd.get("t", 0) + dt
                        if cd["t"] % 0.2 < dt:
                            rx = self.px - 250 + random.random() * 500
                            self.spikes.append([rx, Window.height, 24, 32])
                        if cd["t"] >= 5.0:
                            cd["sub_st"] = 0
                            cd["vis"] = True
            elif l == 2:
                if self.boss_act:
                    if b[5] / b[12] <= 0.3: cd["rage"] = True
                    if cd.get("rage"): b[4] = 6.0 if self.px > b[0] else -6.0; cd["blocking"] = False
                    else:
                        cd["bt"] = cd.get("bt", 0) + dt
                        if cd["bt"] >= 2.5: cd["bt"] = 0; cd["blocking"] = not cd.get("blocking", False)
                    b[0] += b[4]
                    if any(self.coll(b[:4], w) for w in self.walls): b[4] *= -1; b[0] += b[4]
            else:
                if self.boss_act:
                    b[0] += (4 if self.px > b[0] else -4)
                    if random.random() < 0.03:
                        self.projs.append([b[0] + T, b[1] + T, (-6 if self.px < b[0] else 6), 0, 20, 20, 3.0])

            if cd.get("vis", True) and self.coll(p, b[:4]):
                if self.vy <= 0 or self.py > b[1] + b[3] * 0.35:
                    can_hit = not (l == 2 and cd.get("blocking"))
                    if can_hit:
                        b[5] -= 1; self.vy = 12; self.play_sfx("hit")
                        if b[5] <= 0:
                            self.bosses.remove(b)
                            self.boss_def = (len(self.bosses) == 0)
                            self.play_sfx("exp")
                            if self.boss_def and self.cur_snd:
                                try: self.cur_snd.stop()
                                except: pass
                                self.cur_snd = None
                    else:
                        self.vy = 10; self.play_sfx("hit")
                else: self.respawn()

        for g in self.goals:
            if self.coll(p, g) and self.boss_def and not self.cleared:
                self.cleared = True
                if self.cur_snd:
                    try: self.cur_snd.stop()
                    except: pass
                    self.cur_snd = None
                self.play_sfx("vic")

        self.cam_x = min(0, -self.px + Window.width / 2)
        self.canvas.clear(); self.draw_game()

    def draw_ending(self):
        with self.canvas:
            Color(1, 1, 1, 1)
            if self.tex.get("diamond hill"):
                Rectangle(texture=self.tex["diamond hill"], pos=(0, 0), size=self.size)
            else:
                Color(0.1, 0.6, 0.2, 1)
                Rectangle(pos=(0, 0), size=self.size)

            Color(0.2, 0.4, 0.1, 1)
            Rectangle(pos=(0, 0), size=(self.width, 100))

            Color(1, 1, 1, 1)
            if self.tex.get("Flurry"):
                Rectangle(texture=self.tex["Flurry"], pos=(120, 100), size=(self.pw, self.ph))
            else:
                Color(0, 0.6, 1, 1)
                Rectangle(pos=(120, 100), size=(self.pw, self.ph))

            rx, ry = self.rocket_x, self.rocket_y
            rw, rh = 60, 140

            Color(0.9, 0.3, 0.1, 0.8)
            Triangle(points=[rx + 10, ry + rh, rx + rw - 10, ry + rh, rx + rw / 2, ry + rh + 40 + random.random() * 20])
            
            Color(0.2, 0.2, 0.25, 1)
            Rectangle(pos=(rx, ry), size=(rw, rh))

            Color(0.8, 0.1, 0.1, 1)
            Triangle(points=[rx, ry + rh, rx + rw, ry + rh, rx + rw / 2, ry + rh + 35])
            Triangle(points=[rx - 15, ry, rx, ry, rx, ry + 35])
            Triangle(points=[rx + rw, ry, rx + rw + 15, ry, rx + rw, ry + 35])

            Color(1, 0.5, 0, 0.6)
            for _ in range(5):
                fx = rx + random.random() * rw
                fy = ry + random.random() * rh
                Rectangle(pos=(fx, fy), size=(12, 12))

    def draw_game(self):
        info = LEVELS[self.lvl]
        with self.canvas:
            Color(1, 1, 1, 1)
            if self.tex.get(info[0]): Rectangle(texture=self.tex[info[0]], pos=(0, 0), size=self.size)
            else: Color(*info[3]); Rectangle(pos=(0, 0), size=self.size)

            Color(0.2, 0.25, 0.35, 1)
            for w in self.walls: Rectangle(pos=(w[0] + self.cam_x, w[1]), size=(w[2], w[3]))

            for sl, is_u in [(self.sl_up, True), (self.sl_dn, False)]:
                for s in sl:
                    Triangle(points=[s[0] + self.cam_x, s[1], s[0] + s[2] + self.cam_x, s[1], (s[0] + s[2] + self.cam_x if is_u else s[0] + self.cam_x), s[1] + s[3]])

            Color(0.3, 0.6, 0.9, 1)
            for lp in self.loops: Line(circle=(lp[0] + lp[2]/2 + self.cam_x, lp[1] + lp[3]/2, T), width=4)

            Color(0, 1, 1, 1)
            for cp in self.check: Rectangle(pos=(cp[0] + self.cam_x, cp[1]), size=(cp[2], cp[3]))

            if self.boss_def: Color(1, 0.85, 0, 1)
            else: Color(0.4, 0.4, 0.4, 0.8)
            for g in self.goals: Rectangle(pos=(g[0] + self.cam_x, g[1]), size=(g[2], g[3]))

            Color(1, 1, 1, 1)
            for e in self.enemies:
                if self.tex.get("Crab"): Rectangle(texture=self.tex["Crab"], pos=(e[0] + self.cam_x, e[1]), size=(e[2], e[3]))
                else: Color(1, 0.2, 0.2, 1); Rectangle(pos=(e[0] + self.cam_x, e[1]), size=(e[2], e[3])); Color(1, 1, 1, 1)

            for b in self.bosses:
                cd = b[13]
                if cd.get("vis", True):
                    Color(1, 1, 1, 1)
                    if self.tex.get("Dr Roctis"): Rectangle(texture=self.tex["Dr Roctis"], pos=(b[0] + self.cam_x, b[1]), size=(b[2], b[3]))
                    else: Color(1, 0, 0, 1); Rectangle(pos=(b[0] + self.cam_x, b[1]), size=(b[2], b[3])); Color(1, 1, 1, 1)
                    if cd.get("blocking"): Color(0, 0.5, 1, 0.5); Rectangle(pos=(b[0] + self.cam_x - 5, b[1] - 5), size=(b[2] + 10, b[3] + 10))
                    elif cd.get("rage"): Color(1, 0, 0, 0.4); Rectangle(pos=(b[0] + self.cam_x - 5, b[1] - 5), size=(b[2] + 10, b[3] + 10))

            Color(1, 0.3, 0, 1)
            for bm in self.bombs: Rectangle(pos=(bm[0] + self.cam_x, bm[1]), size=(bm[4], bm[5]))

            Color(0.8, 0.2, 1, 1)
            for pr in self.projs: Rectangle(pos=(pr[0] + self.cam_x, pr[1]), size=(pr[4], pr[5]))

            Color(0.8, 0.3, 0.1, 1)
            for sp in self.spikes: Triangle(points=[sp[0] + self.cam_x, sp[1] + sp[3], sp[0] + sp[2] + self.cam_x, sp[1] + sp[3], sp[0] + sp[2]/2 + self.cam_x, sp[1]])

            Color(1, 1, 1, 1)
            if self.tex.get("Flurry"): Rectangle(texture=self.tex["Flurry"], pos=(self.px + self.cam_x, self.py), size=(self.pw, self.ph))
            else: Color(0, 0.6, 1, 1); Rectangle(pos=(self.px + self.cam_x, self.py), size=(self.pw, self.ph))

            Color(1, 0, 0, 0.2); Rectangle(pos=(0, 0), size=(self.width * 0.2, 200))
            Color(0, 0, 1, 0.2); Rectangle(pos=(self.width * 0.2, 0), size=(self.width * 0.2, 200))
            Color(0, 1, 0, 0.2); Rectangle(pos=(self.width * 0.5, 0), size=(self.width * 0.5, 200))

class Flurry8BitApp(App):
    def build(self): return GameWidget()

if __name__ == "__main__":
    Flurry8BitApp().run()